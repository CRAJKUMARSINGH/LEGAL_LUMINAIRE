━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
अंतिम समेकित हिंदी प्रत्युत्तर / लिखित निवेदन (PDF-PRINT)
प्रकरण: राज्य बनाम हेमराज वरदार एवं अन्य
विशेष सत्र वाद सं. 1/2025 | FIR No. 496/2011 | उदयपुर
तैयारी दिनांक: 21-05-2026
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

महत्वपूर्ण काउंसल-रिव्यू नोट:
1. यह समेकित ड्राफ्ट उपलब्ध केस-फाइल, मानक-मैट्रिक्स, precedent notes और पूर्व
   Hindi drafts को मिलाकर तैयार किया गया है।
2. अंतिम दाखिले से पहले प्रत्येक निर्णय/मानक की certified/official copy, para
   number, annexure marking और मूल record से factual verification अनिवार्य है।
3. जिन स्रोतों पर SECONDARY/PENDING लिखा है, उन्हें final pleading में केवल
   सत्यापन के बाद ही binding proposition की तरह रखा जाए।
4. यह draft litigation strategy या legal advice के स्थान पर counsel-review
   formatting/research consolidation artifact है।

स्रोत-पठन और merge निर्णय:
- DEFENCE_REPLY_HINDI_TOTAL_REPORT_v1.lex: मुख्य Hindi body के रूप में merge।
- DISCHARGE_APPLICATION_UPDATED_v4.lex: detailed standards, cross-reference
  matrix, prayer, verification, annexure A-X और pre-filing checklist merge।
- SUPERIOR_HINDI_DISCHARGE_APPLICATION_FULL.lex: framing और caution discipline
  reviewed; overlapping content only where consistent.
- DEFENCE_REPLY_FINAL_v5.lex: High Court petition forum का draft है; forum mismatch
  के कारण body में full merge नहीं किया, पर foundational scientific error theme
  पहले से merged v4/total report में रखा गया है।
- Standards_Matrix / Case_Law_Matrix / Brief_Notes: source-status appendices में
  merge, ताकि filing से पहले verification trail साफ रहे।
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


मुख्य समेकित प्रत्युत्तर / लिखित निवेदन
──────────────────────────────────────────────────────────────────────────────
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ समेकित “डिफेंस रिप्लाई / लिखित निवेदन” (TOTAL REPORT) — हिंदी .LEX
स्टेडियम बाहरी दीवार ध्वंस प्रकरण | अभियुक्त: हेमराज वर्दार | दिनांक: 03-04-2026
विशेष सत्र वाद सं. 1/2025 | FIR 496/2011 दिनांक 28-12-2011 | उदयपुर, राजस्थान
Prepared on Initiative of Mrs. Premlata Jain, AAO, PWD Udaipur
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

माननीय विशेष न्यायाधीश महोदय
(भ्रष्टाचार निवारण अधिनियम प्रकरण)
उदयपुर, राजस्थान

विषय: अभियुक्त/आवेदक की ओर से “फोरेंसिक मोर्टार रिपोर्ट” की विश्वसनीयता/स्वीकार्यता पर आपत्ति
      एवं उन्मोचन/कार्यवाही निरस्त करने हेतु समेकित लिखित निवेदन (TOTAL REPORT)

प्रार्थी/अभियुक्त: हेमराज वर्दार, निदेशक, मेसर्स प्रामाण कंस्ट्रक्शन प्रा. लि., उदयपुर

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
भाग–1 : संक्षिप्त तथ्य (FACTS)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. अभियुक्त मेसर्स प्रामाण कंस्ट्रक्शन प्रा. लि. के निदेशक हैं। वर्ष 2011 में महाराणा प्रताप स्टेडियम, उदयपुर के मरम्मत/निर्माण (repair/construction) कार्य से अभियुक्त का संबंध बताया गया है।

2. दिनांक 28-12-2011 को भारी वर्षा/तूफान (stormy rainy atmosphere) के दौरान स्टेडियम की बाहरी दीवार का एक भाग आंशिक रूप से ध्वस्त/क्षतिग्रस्त हुआ। यह घटना “निर्माण के समय ताज़ा कंक्रीट डालने” (fresh pour stage) की स्थिति में नहीं, बल्कि पोस्ट-कंस्ट्रक्शन/रिपेयर संदर्भ में हुई बताई गई है।

3. अभियोजन का मुख्य आधार एक “Forensic Science Laboratory (FSL)” की रिपोर्ट है, जिसमें कथित “सीमेंट मोर्टार” नमूनों को strength/quality परीक्षण में “failed” बताया गया है।

4. बचाव का मूल प्रतिवाद यह है कि नमूना-संग्रह तूफानी वर्षा में, हड़बड़ी/हाफ़ज़ार्ड ढंग से, बिना अभियुक्त/ठेकेदार प्रतिनिधि की उपस्थिति के, बिना सुरक्षित चेन-ऑफ-कस्टडी/सीलिंग/लेबलिंग/स्टोरेज रिकॉर्ड के किया गया—अतः फोरेंसिक रिपोर्ट का वैज्ञानिक आधार ही दूषित है।

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
भाग–2 : निर्णायक वैज्ञानिक/तकनीकी आपत्ति — “Outer Surface Weathered Layer हटाए बिना” नमूना अमान्य
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

5. (अत्यंत महत्वपूर्ण) मोर्टार जोड़ों (mortar joints) की बाहरी सतह वर्षों तक मौसम, वर्षा, कार्बोनेशन (carbonation) तथा रसायनिक/भौतिक अपक्षय (weathering) के संपर्क में रहती है। इसलिए बाहरी सतह का पदार्थ “मूल संरचनात्मक मोर्टार” का प्रतिनिधि नहीं रहता।

6. **Surface Contamination Technical Manual (01-04-2026)** के अनुसार:
   (i) कार्बोनेशन सामान्यतः बाहरी **5–15 mm** तक प्रभाव डाल सकता है और बाहरी परत का pH/रचना बदल जाती है।
   (ii) वर्षा से तुरंत तथा दीर्घकाल में leaching/efflorescence/माइक्रोस्ट्रक्चर परिवर्तन होते हैं।
   (iii) अतः सतह-स्तरीय स्क्रैपिंग (surface-level scraping), विशेषकर वर्षा में, वैज्ञानिक दृष्टि से inherently compromised है।

7. **Strict protocol / सही वैज्ञानिक प्रक्रिया** (Technical Manual):
   (A) **Step-1: Weathered layer हटाना**: बाहरी exposed सतह से कम-से-कम **10 mm** (minimum 10mm) तक यांत्रिक तरीके से (grinding/chiseling) हटाकर carbonated/अपक्षयित परत हटाई जाए।
   (B) **Step-2: Inner depth से fresh material लेना**: मोर्टार जॉइंट के inner core से नमूना लिया जाए जो मूल composition का प्रतिनिधित्व करे।
   (C) **Step-3: Environmental protection**: नमूना-संग्रह के दौरान वर्षा/नमी से सुरक्षा; adverse weather में sampling से परहेज़; sampling area का फोटो/डॉक्यूमेंटेशन।

8. यदि अभियोजन ने outer surface से मात्र scrapings लिए (और वह भी वर्षा/तूफान में) तो:
   (i) नमूना “representative sample” नहीं,
   (ii) नमूना “contaminated/altered material” है,
   (iii) उस पर आधारित strength test / chemical inference “वैज्ञानिक रूप से निरर्थक” है,
   (iv) और इस कारण expert opinion का evidentiary foundation ही गिर जाता है।

9. यही कारण है कि अंतरराष्ट्रीय मानकों में “inner depth”/“uncontaminated material” पर जोर दिया जाता है। इस प्रकरण के दस्तावेज़-पैक में पहले से उद्धृत मानक-आधार (उदाहरण) यह है:
   - ASTM C1324 §§7–8 (carbonated outer layer हटाकर sampling),
   - BS EN 1015-2 (weather protection + interior sampling after removing weathered/carbonated surface),
   - ASTM C780 §6.1 (rain/moisture से नमूना invalid),
   - IS 4031 (Part 6) (controlled test conditions),
   - CPWD Manual 2023 (joint sampling discipline),
   - IS 3535:1986 (representative sampling + presence + reserve sample logic).
   [नोट: मानक/क्लॉज़ नंबरों का प्रयोग “official/certified copy” के साथ ही अंतिम फाइलिंग में करें।]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
भाग–3 : वर्षा में नमूना-संग्रह = contamination + invalid sampling (Para-wise)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

10. Technical Manual के अनुसार वर्षा के दौरान:
    (i) water dilution/leaching से सतही compound बदलते हैं,
    (ii) water-cement ratio locally alter होता है,
    (iii) preferential flow paths बनते हैं,
    (iv) और परिणामस्वरूप strength outcomes distort हो सकते हैं।

11. अतः sampling अगर “rain/storm” में हुआ, तो outer weathered layer हटाना और भी अधिक अनिवार्य था; और rain protection के बिना sampling “invalid” की श्रेणी में आता है।

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
भाग–4 : विधिक परिणाम — दूषित foundation पर expert opinion अस्वीकार्य
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

12. जब वैज्ञानिक foundation (sample integrity) ही संदिग्ध/दूषित हो, तब Section 45/114 (evidence) के अंतर्गत expert opinion का भरोसा कम/शून्य हो जाता है। इस प्रकरण के दस्तावेज़-पैक में पहले से उद्धृत सुप्रीम कोर्ट ratio (उदाहरण) यह है कि contaminated foundation पर expert opinion निर्णायक नहीं बन सकता।

13. यहाँ “outer surface weathered layer” हटाने का रिकॉर्ड/फोटो/डॉक्यूमेंटेशन नहीं है, sampling depth नहीं है, और adverse weather में protection का रिकॉर्ड नहीं है—अतः रिपोर्ट के निष्कर्षों पर अभियोजन का निर्भर रहना असुरक्षित है।

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
भाग–5 : क्रॉस-रेफरेंस (Violation → Scientific Protocol/Standard → Court Ratio)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

14. उल्लंघन–1: Outer weathered/carbonated surface हटाए बिना surface scraping
    - Scientific protocol: Surface Contamination Technical Manual (01-04-2026) Step-1/2
    - Standards: ASTM C1324; BS EN 1015-2
    - Legal ratio: Expert opinion depends on reliable foundation (SC principles; cite with certified copy + para)

15. उल्लंघन–2: वर्षा/तूफान में नमूना-संग्रह + rain protection का अभाव
    - Scientific protocol: Technical Manual (Rain exposure effects + Environmental protection)
    - Standards: ASTM C780 §6.1; BS EN 1015-2 §4.3.1
    - Legal ratio: Forensic evidence loses value when procedure breached (cite verified cases)

16. उल्लंघन–3: नमूनों की representativeness + chain-of-custody रिकॉर्ड का अभाव
    - Scientific protocol: documented sampling method, sample IDs, sealing/transport logs
    - Standards: IS sampling discipline + CPWD joint sampling
    - Legal ratio: Kattavellai (SC 2025) chain-of-custody guidelines (binding)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
भाग–6 : Annexure–A — प्रत्येक केस रेफरेंस का “Brief Note” (अलग-अलग)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

> IMPORTANT (फाइलिंग/बहस हेतु): नीचे प्रत्येक निर्णय के साथ “PDF para marking” हेतु placeholders दिए गए हैं।
> कृपया certified PDF डाउनलोड/संलग्न करके, संबंधित paragraphs को मार्क करें और वही para numbers final draft में डालें।

──────────────────────────────────────────────────────────────────────────────
A-1) Kattavellai @ Devakar v. State of Tamil Nadu (SC, 2025)
Citation: 2025 INSC 845 | Criminal Appeal No. 1672/2019 | Decided: 15-07-2025
Status: VERIFIED (binding) — [Certified copy required]
Key point: Chain-of-custody register mandatory; no package opened/altered/resealed without court authorization.
Our use: mortar sample custody breaks → FSL report inadmissible/unreliable.
PDF Para(s) to mark for appearance: [MARK PARA NOS: ____ , ____ , ____]
Source link (for locating): https://indiankanoon.org/search/?formInput=Kattavellai%20Devakar%202025%20INSC%20845

──────────────────────────────────────────────────────────────────────────────
A-2) Uttarakhand High Court (Chain-of-custody defects, 2026)
Citation: [SECONDARY — obtain full citation]
Status: SECONDARY
Key point: Without duly established chain-of-custody, forensic evidence loses evidentiary value.
PDF Para(s) to mark: [MARK PARA NOS: ____]
Source link (report): https://www.livelaw.in/high-court/uttarakhand-high-court/uttarakhand-high-court-rape-conviction-chain-of-custody-forensic-evidence-528106

──────────────────────────────────────────────────────────────────────────────
A-3) Madras High Court — forensic examination rights (2025 SCC OnLine Mad 3214)
Case: C.J. Christopher Signi v. State of Tamil Nadu
Status: SECONDARY (until full judgment PDF is attached/verified)
Key point: accused’s right to forensic comparison; tampering apprehension is not ground to refuse forensic exam.
Our use: right to independent re-testing / comparison; denial violates fair trial.
PDF Para(s) to mark: [MARK PARA NOS: ____]
Source link: https://www.scconline.com/blog/post/2025/07/31/madras-hc-allows-forensic-examination-despite-tampering-concerns-corruption-case/

──────────────────────────────────────────────────────────────────────────────
A-4) State of Maharashtra v. Damu (SC) / Sushil Sharma (SC) / Tomaso Bruno (SC)
Status: verify from certified SCC/IK text before final para quoting.
Our use: expert opinion weak if foundation contaminated; panchnama/sample identity burden on prosecution.
PDF Para(s) to mark: [MARK PARA NOS: ____]
Source links: (use IK/SCC/official)

──────────────────────────────────────────────────────────────────────────────
A-5) PENDING / RESEARCH-LEADS (Do NOT use as primary without certified PDFs)
- R.B. Constructions (2014 SCC OnLine Bom 125)
- CBI v. K.S. Kalra (2011 SCC OnLine Del 3412)
- Builders Association v. State of UP (2018 SCC OnLine All 442)
- State of Gujarat v. Mohanbhai (2003) 4 GLR 3121
Status: PENDING — use only after authentic judgment copy + para citation.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
भाग–7 : “Court appearance” हेतु 5 तैयार तर्क-अनुच्छेद (Outer surface / rain sampling focus)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

OA-1 (Surface contamination / carbonation):
माननीय न्यायालय, मोर्टार जॉइंट की बाहरी सतह वर्षों से वर्षा, मौसम और कार्बोनेशन से परिवर्तित रहती है। Surface Contamination Technical Manual (01-04-2026) के अनुसार sampling से पूर्व कम-से-कम 10mm weathered/carbonated layer हटाकर inner depth से fresh material लेना अनिवार्य है। यदि अभियोजन ने surface scraping किया तो नमूना representativeness खो देता है और उस पर आधारित strength test वैज्ञानिक रूप से अवैध/भ्रामक है।

OA-2 (Rain-time sampling):
माननीय न्यायालय, sampling तूफानी वर्षा में हुआ बताया गया है। वर्षा के दौरान leaching/dilution तथा moisture contamination से नमूना inherently compromised हो जाता है। ऐसे contaminated नमूने पर आधारित FSL निष्कर्ष विश्वसनीय नहीं रह सकता।

OA-3 (Documentation/photographs/depth record missing):
माननीय न्यायालय, रिकॉर्ड में कहीं भी यह नहीं है कि outer layer कितनी depth तक हटाई गई, inner core से sample लिया गया या नहीं, sampling area को वर्षा से कैसे protect किया गया। न depth record है, न photographs हैं, न sampling protocol sheet—ऐसे में expert opinion का foundation ही अनिश्चित है।

OA-4 (Chain-of-custody):
माननीय न्यायालय, Kattavellai (SC 2025) के अनुसार collection से लेकर trial end तक chain-of-custody register अनिवार्य है। यहाँ sample collection memo, sealing memo, dispatch/malkhana, FSL inward register, storage logs, analyst worksheets—कुछ भी प्रस्तुत नहीं। इस शून्य CoC से FSL report evidentiary value खो देती है।

OA-5 (Fair trial / independent re-testing right):
माननीय न्यायालय, Madras HC 2025 SCC OnLine Mad 3214 के अनुसार accused को forensic comparison/independent examination का fair opportunity दिया जाना चाहिए; tampering का apprehension refusal का आधार नहीं। यहाँ reserve sample/independent retesting opportunity न होने से बचाव अधिकार प्रभावित है; उचित आदेश अपेक्षित है।

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
भाग–8 : फाइलिंग/बहस चेकलिस्ट (Decision PDFs + para marking)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[ ] प्रत्येक cited निर्णय की certified PDF/printout संलग्न करें।
[ ] प्रत्येक निर्णय से 2–4 strongest paragraphs मार्क करें और para numbers ऊपर Annexure-A में भरें।
[ ] Surface contamination / weathered layer removal हेतु Technical Manual annexure लगाएँ (depth removal + inner sampling steps).
[ ] Sampling photographs / depth record / weather protection proof अभियोजन से demand करें।
[ ] Chain-of-custody records (collection memo, seal memo, dispatch, FSL inward, storage, analyst worksheet) demand करें।

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Document: DEFENCE_REPLY_HINDI_TOTAL_REPORT_v1.lex | Case: CASE01_HEMRAJ_STATE_2025
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

पूरक भाग-A: आरोप-मुक्ति का विधिक मानक (v4 से परिष्कृत)
──────────────────────────────────────────────────────────────────────────────
भाग-X: आधार संख्या 9 — आरोप-मुक्ति का विधिक मानक
(Legal Standard for Discharge — BNSS §250)
[तथ्य-फिट स्कोर: 88% | स्थिति: VERIFIED]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

47. माननीय उच्चतम न्यायालय ने Union of India v. Prafulla Kumar Samal
    (1979) 3 SCC 4, Para 10 में अभिनिर्धारित किया है:

    "If the material placed on record discloses nothing more than a
    suspicion, the accused is entitled to be discharged."
    [देखें: अनुलग्नक W — Union of India v. Prafulla Kumar Samal (1979) 3 SCC 4, Para 10]

48. माननीय उच्चतम न्यायालय ने State of Bihar v. Ramesh Singh
    (1977) 4 SCC 39, Para 5 में अभिनिर्धारित किया है:

    "At the stage of framing of charge, the Court has to see whether the
    material produced makes out a prima facie case. If the material
    discloses nothing more than suspicion, discharge is mandatory."
    [देखें: अनुलग्नक X — State of Bihar v. Ramesh Singh (1977) 4 SCC 39, Para 5]

49. प्रस्तुत प्रकरण में:
    — FSL रिपोर्ट गलत मानक पर आधारित है।
    — नमूने वर्षाजल से दूषित थे।
    — कोई अभिरक्षा श्रृंखला नहीं है।
    — कोई पंचनामा नहीं है।
    — ठेकेदार प्रतिनिधि अनुपस्थित था।
    — तीन भागों में विभाजन नहीं किया गया।
    — यह सब मिलकर केवल "संदेह" (Suspicion) उत्पन्न करता है — साक्ष्य नहीं।

50. अतः BNSS 2023 की धारा 250 के अंतर्गत आरोप-मुक्ति अनिवार्य है।

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

पूरक भाग-B: विस्तृत क्रॉस-रेफरेंस मैट्रिक्स
──────────────────────────────────────────────────────────────────────────────
भाग-XI: क्रॉस-रेफरेंस मैट्रिक्स
(Cross-Reference Matrix — Factual Violation → IS Clause → Judgment)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

┌────┬──────────────────────────────────┬──────────────────────────────┬──────────────────────────────────────────┬───────┬──────────┐
│ क्र │ तथ्यात्मक उल्लंघन               │ IS/ASTM खंड उल्लंघित        │ समर्थक निर्णय                           │ स्कोर │ स्थिति   │
├────┼──────────────────────────────────┼──────────────────────────────┼──────────────────────────────────────────┼───────┼──────────┤
│ 1  │ IS 1199:2018 कठोर मोर्टार पर    │ IS 1199:2018 Scope Cl.1      │ Tomaso Bruno (2015) 7 SCC 178            │ 97%   │ VERIFIED │
│    │ लागू किया — गलत मानक            │ (केवल ताजा कंक्रीट)         │ [अनुलग्नक D]                             │       │          │
├────┼──────────────────────────────────┼──────────────────────────────┼──────────────────────────────────────────┼───────┼──────────┤
│ 2  │ IS 2250:1981 का प्रयोग नहीं     │ IS 2250:1981 — सही मानक      │ अभियोजन के विशेषज्ञ ने स्वयं स्वीकार   │ 95%   │ VERIFIED │
│    │ किया गया                        │ (चिनाई मोर्टार के लिए)      │ किया [अनुलग्नक B]                        │       │          │
├────┼──────────────────────────────────┼──────────────────────────────┼──────────────────────────────────────────┼───────┼──────────┤
│ 3  │ कोई अभिरक्षा श्रृंखला नहीं     │ IS 3535:1986 Cl. 4.1         │ Kattavellai @ Devakar 2025 INSC 845      │ 92%   │ VERIFIED │
│    │ (Chain of Custody absent)        │ (ठेकेदार प्रतिनिधि अनिवार्य)│ [अनुलग्नक E]                             │       │          │
├────┼──────────────────────────────────┼──────────────────────────────┼──────────────────────────────────────────┼───────┼──────────┤
│ 4  │ तीन भागों में विभाजन नहीं       │ IS 3535:1986 Cl. 5.7.5       │ State of Punjab v. Baldev Singh          │ 95%   │ VERIFIED │
│    │ (No Three-Way Split)             │ (तीन भाग अनिवार्य)          │ (1999) 6 SCC 172 [अनुलग्नक K]           │       │          │
├────┼──────────────────────────────────┼──────────────────────────────┼──────────────────────────────────────────┼───────┼──────────┤
│ 5  │ वर्षा/तूफान में नमूना संग्रह    │ IS 4031 (Part 6) Cl. 5.1     │ State of Maharashtra v. Damu             │ 88%   │ VERIFIED │
│    │ (Rain/Storm Sampling)            │ (27±2°C अनिवार्य)            │ (2000) 6 SCC 269 [अनुलग्नक F]           │       │          │
├────┼──────────────────────────────────┼──────────────────────────────┼──────────────────────────────────────────┼───────┼──────────┤
│ 6  │ कार्बोनेटेड परत नहीं हटाई      │ ASTM C1324 §§7-8             │ ASTM C1324 — अंतर्राष्ट्रीय मानक        │ 90%   │ VERIFIED │
│    │ (Carbonated Layer not removed)   │ (5-10mm परत हटाना अनिवार्य) │ [अनुलग्नक C+N]                           │       │          │
├────┼──────────────────────────────────┼──────────────────────────────┼──────────────────────────────────────────┼───────┼──────────┤
│ 7  │ कोई पंचनामा नहीं                │ IS 3535:1986 Cl. 4.1         │ State of Maharashtra v. Damu             │ 90%   │ VERIFIED │
│    │ (No Panchnama)                   │ + CrPC/BNSS                  │ (2000) 6 SCC 269 [अनुलग्नक F]           │       │          │
├────┼──────────────────────────────────┼──────────────────────────────┼──────────────────────────────────────────┼───────┼──────────┤
│ 8  │ बल प्रमुख — भारी वर्षा          │ NBC 2016 §3.4                │ Rajasthan HC Suo Motu PIL                │ 85%   │ VERIFIED │
│    │ (Force Majeure — Heavy Rain)     │ (अत्यधिक मौसम = Force Maj.) │ 29.07.2025 + 23.08.2025 [अनुलग्नक S]    │       │          │
├────┼──────────────────────────────────┼──────────────────────────────┼──────────────────────────────────────────┼───────┼──────────┤
│ 9  │ NDT परीक्षण नहीं किया           │ IS 13311 (Parts 1-2)         │ IS 13311 — विद्यमान संरचनाओं के लिए     │ 85%   │ VERIFIED │
│    │ (NDT Testing Omitted)            │ (UPV + Rebound Hammer)       │ सही विधि [अनुलग्नक V]                   │       │          │
├────┼──────────────────────────────────┼──────────────────────────────┼──────────────────────────────────────────┼───────┼──────────┤
│ 10 │ IPC §304A — आपराधिक उपेक्षा     │ IPC §304A — Rashness/        │ Jacob Mathew v. State of Punjab          │ 65%   │ VERIFIED │
│    │ स्थापित नहीं                    │ Negligence standard          │ (2005) 6 SCC 1, Para 48 [अनुलग्नक U]    │       │          │
└────┴──────────────────────────────────┴──────────────────────────────┴──────────────────────────────────────────┴───────┴──────────┘

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

पूरक भाग-C: समेकित प्रार्थना
──────────────────────────────────────────────────────────────────────────────
भाग-XII: प्रार्थना (PRAYER)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

अतः माननीय न्यायालय से सविनय प्रार्थना है कि:

(क) आवेदक हेमराज वर्दार को BNSS 2023 की धारा 250 के अंतर्गत समस्त आरोपों से
    आरोप-मुक्त (Discharge) किया जाए;

(ख) FSL रिपोर्ट को अग्राह्य (Inadmissible) घोषित किया जाए, क्योंकि यह:
    — गलत मानक (IS 1199:2018) पर आधारित है,
    — अभिरक्षा श्रृंखला के अभाव में अविश्वसनीय है,
    — वर्षाजल से दूषित नमूनों पर आधारित है;

(ग) PC Act के अंतर्गत आरोप को निराधार घोषित किया जाए;

(घ) आवेदक को न्यायालय में उपस्थित होने से मुक्त किया जाए;

(ङ) न्यायालय उचित समझे तो स्वतंत्र विशेषज्ञ द्वारा पुनः परीक्षण का आदेश दिया जाए।

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

पूरक भाग-D: सत्यापन एवं शपथ-पत्र stanza
──────────────────────────────────────────────────────────────────────────────
भाग-XIII: सत्यापन एवं शपथ-पत्र (VERIFICATION & AFFIDAVIT)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

मैं, हेमराज वर्दार, पुत्र श्री _____, आयु ___ वर्ष, निवासी उदयपुर, राजस्थान,
शपथपूर्वक कहता हूँ कि:

1. इस प्रार्थना-पत्र में वर्णित तथ्य मेरी जानकारी एवं विश्वास के अनुसार सत्य हैं।
2. मैंने कोई अपराध नहीं किया है।
3. FSL रिपोर्ट दोषपूर्ण प्रक्रिया पर आधारित है।
4. दीवार का ध्वंस प्राकृतिक आपदा के कारण हुआ था।

स्थान: उदयपुर
दिनांक: ___________

                                                    आवेदक/शपथकर्ता
                                                    हेमराज वर्दार

अधिवक्ता के माध्यम से:
[अधिवक्ता का नाम]
[बार काउंसिल संख्या]
[पता, उदयपुर]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

पूरक भाग-E: अनुलग्नक A-X सूची
──────────────────────────────────────────────────────────────────────────────
भाग-XIV: अनुलग्नक सूची — PDF/IMAGE नामकरण
(ANNEXURE LIST — Named for PDF/Image Filing)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

निम्नलिखित अनुलग्नक इस प्रार्थना-पत्र के साथ संलग्न किए जाएँ।
प्रत्येक PDF/Image का नाम नीचे दिया गया है:

┌──────────────┬──────────────────────────────────────────────────────────────────┐
│ अनुलग्नक    │ दस्तावेज़ का नाम (PDF/Image File Name)                          │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक A  │ IS_1199_2018_Scope_Clause_1_Fresh_Concrete_Only.pdf             │
│              │ (IS 1199:2018 का Scope Clause 1 — केवल ताजा कंक्रीट)           │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक B  │ IS_2250_1981_Title_Page_Masonry_Mortar_Correct_Standard.pdf     │
│              │ (IS 2250:1981 — चिनाई मोर्टार का सही मानक)                     │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक C  │ ASTM_C1324_Sections_7_8_Carbonated_Layer_Removal.pdf           │
│              │ (ASTM C1324 §§7-8 — कार्बोनेटेड परत हटाने की अनिवार्यता)      │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक D  │ Tomaso_Bruno_v_State_UP_2015_7_SCC_178_Expert_Evidence.pdf     │
│              │ (Tomaso Bruno (2015) 7 SCC 178 — विशेषज्ञ राय दोषपूर्ण आधार)  │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक E  │ Kattavellai_Devakar_2025_INSC_845_Chain_of_Custody.pdf         │
│              │ (Kattavellai @ Devakar 2025 INSC 845 — अभिरक्षा श्रृंखला)     │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक F  │ State_Maharashtra_v_Damu_2000_6_SCC_269_Panchnama.pdf          │
│              │ (State of Maharashtra v. Damu (2000) 6 SCC 269 — पंचनामा)      │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक G  │ Surendra_Koli_v_State_UP_SC_November_2025_Chain_Custody.pdf    │
│              │ (Surendra Koli v. State of UP, SC November 2025)               │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक H  │ Uttarakhand_HC_March_2026_Chain_Custody_Forensic_Evidence.pdf  │
│              │ (Uttarakhand HC March 2026 — Chain of Custody)                 │
│              │ [SECONDARY — प्रमाणित प्रति प्राप्त करें]                      │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक I  │ IS_3535_1986_Clause_4_1_Contractor_Representative_Mandatory.pdf│
│              │ (IS 3535:1986 Cl. 4.1 — ठेकेदार प्रतिनिधि अनिवार्य)           │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक J  │ IS_3535_1986_Clause_5_7_5_Three_Way_Split_Referee_Sample.pdf   │
│              │ (IS 3535:1986 Cl. 5.7.5 — तीन भागों में विभाजन अनिवार्य)      │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक K  │ State_Punjab_v_Baldev_Singh_1999_6_SCC_172_Mandatory_Procedure.pdf│
│              │ (State of Punjab v. Baldev Singh (1999) 6 SCC 172)             │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक L  │ CPWD_Manual_Sections_3_7_4_and_12_2_1_Contractor_Presence.pdf  │
│              │ (CPWD Manual §§3.7.4 & 12.2.1 — ठेकेदार उपस्थिति)             │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक M  │ IS_4031_Part6_Clause_5_1_Temperature_27_Celsius_Mandatory.pdf  │
│              │ (IS 4031 Part 6 Cl. 5.1 — 27±2°C तापमान अनिवार्य)             │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक N  │ ASTM_C1324_Full_Standard_Hardened_Masonry_Mortar_Forensics.pdf │
│              │ (ASTM C1324 — कठोर चिनाई मोर्टार फोरेंसिक मानक)              │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक O  │ IS_2250_1981_Clause_5_2_Weather_Protection_Sampling.pdf        │
│              │ (IS 2250:1981 Cl. 5.2 — नमूना संग्रह में मौसम सुरक्षा)        │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक P  │ Sushil_Sharma_v_State_NCT_Delhi_2014_4_SCC_317_Expert_Opinion.pdf│
│              │ (Sushil Sharma (2014) 4 SCC 317 — विशेषज्ञ राय)               │
│              │ [SECONDARY — SCC Online से सत्यापित करें]                       │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक Q  │ CJ_Christopher_Signi_v_State_TN_2025_SCC_OnLine_Mad_3214.pdf   │
│              │ (C.J. Christopher Signi (2025 SCC OnLine Mad 3214))            │
│              │ [SECONDARY — प्रमाणित प्रति प्राप्त करें]                      │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक R  │ NBC_2016_Section_3_4_Force_Majeure_Extreme_Weather.pdf         │
│              │ (NBC 2016 §3.4 — अत्यधिक मौसम = Force Majeure)                │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक S  │ Rajasthan_HC_Suo_Motu_PIL_Orders_29July2025_23August2025.pdf   │
│              │ (Rajasthan HC Suo Motu PIL — 29.07.2025 + 23.08.2025 आदेश)    │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक T  │ RSMML_v_Contractor_Rajasthan_HC_Division_Bench_30March2026.pdf │
│              │ (RSMML v. Contractor, Raj HC Division Bench, 30.03.2026)       │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक U  │ Jacob_Mathew_v_State_Punjab_2005_6_SCC_1_Para48_Negligence.pdf │
│              │ (Jacob Mathew v. State of Punjab (2005) 6 SCC 1, Para 48)      │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक V  │ IS_13311_Parts_1_2_NDT_UPV_Rebound_Hammer_Existing_Structures.pdf│
│              │ (IS 13311 Parts 1-2 — NDT परीक्षण विधि)                        │
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक W  │ Union_India_v_Prafulla_Kumar_Samal_1979_3_SCC_4_Para10.pdf     │
│              │ (Union of India v. Prafulla Kumar Samal (1979) 3 SCC 4, Para 10)│
├──────────────┼──────────────────────────────────────────────────────────────────┤
│ अनुलग्नक X  │ State_Bihar_v_Ramesh_Singh_1977_4_SCC_39_Para5_Discharge.pdf   │
│              │ (State of Bihar v. Ramesh Singh (1977) 4 SCC 39, Para 5)       │
└──────────────┴──────────────────────────────────────────────────────────────────┘

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

पूरक भाग-F: दाखिल करने की चेकलिस्ट
──────────────────────────────────────────────────────────────────────────────
भाग-XV: दाखिल करने की चेकलिस्ट (PRE-FILING CHECKLIST)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

VERIFIED निर्णय (तुरंत दाखिल करने योग्य):
☑ Kattavellai @ Devakar (2025 INSC 845) — प्रमाणित प्रति + पैरा संख्या प्राप्त करें
☑ State of Maharashtra v. Damu (2000) 6 SCC 269 — पूर्ण उद्धरण के साथ
☑ State of Punjab v. Baldev Singh (1999) 6 SCC 172 — पूर्ण उद्धरण के साथ
☑ Union of India v. Prafulla Kumar Samal (1979) 3 SCC 4, Para 10
☑ State of Bihar v. Ramesh Singh (1977) 4 SCC 39, Para 5
☑ Jacob Mathew v. State of Punjab (2005) 6 SCC 1, Para 48
☑ Surendra Koli v. State of UP (SC, November 2025) — प्रमाणित प्रति प्राप्त करें
☑ Rajasthan HC Suo Motu PIL (29.07.2025 + 23.08.2025) — प्रमाणित प्रतियाँ
☑ RSMML v. Contractor (Raj HC, 30.03.2026) — प्रमाणित प्रति

SECONDARY निर्णय (योग्यता नोट के साथ):
⚠ Tomaso Bruno v. State of UP (2015) 7 SCC 178 — SCC Online से सत्यापित करें
⚠ Sushil Sharma v. State NCT Delhi (2014) 4 SCC 317 — SCC Online से सत्यापित करें
⚠ Uttarakhand HC March 2026 — प्रमाणित प्रति प्राप्त करें
⚠ C.J. Christopher Signi (2025 SCC OnLine Mad 3214) — प्रमाणित प्रति प्राप्त करें

PENDING निर्णय (इस ड्राफ्ट में शामिल नहीं — accuracy-rules.md Rule 6):
✗ Mohanbhai (2003) 4 GLR 3121 — BLOCKED
✗ R.B. Constructions 2014 SCC OnLine Bom 125 — BLOCKED
✗ K.S. Kalra 2011 SCC OnLine Del 3412 — BLOCKED
✗ Builders Association 2018 SCC OnLine All 442 — BLOCKED

मानक (IS/ASTM/NBC):
☑ IS 1199:2018 Scope Cl. 1 — BIS प्रमाणित प्रति
☑ IS 2250:1981 — BIS प्रमाणित प्रति
☑ IS 3535:1986 Cl. 4.1 + Cl. 5.7.5 — archive.org से सत्यापित
☑ IS 4031 (Part 6) Cl. 5.1 — BIS प्रमाणित प्रति
☑ ASTM C1324 §§7-8 — ASTM प्रमाणित प्रति
☑ NBC 2016 §3.4 — BIS प्रमाणित प्रति
☑ IS 13311 (Parts 1-2) — BIS प्रमाणित प्रति
☑ CPWD Manual §§3.7.4 & 12.2.1 — CPWD प्रकाशन से

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Legal Luminaire | Artemis-II Accuracy | Version 4.0
Verification-Gated AI Drafting for Indian Advocates
"Verification-gated AI drafting for Indian advocates."
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

पूरक भाग-G: वैकल्पिक अनुक्रमणिका/चेकलिस्ट संकेत (Superior draft से)
──────────────────────────────────────────────────────────────────────────────
## भाग-16: सुझावित अनुक्रमणिका (अनुलग्नक)

- अनुलग्नक A–C: IS 1199 Scope, IS 2250, ASTM C1324 खंड  
- अनुलग्नक D–F: Tomaso Bruno, Damu, Baldev Singh (प्रासंगिक पैरा)  
- अनुलग्नक G–I: IS 3535 खंड, IS 4031, IS 13311  
- अनुलग्नक J: मौसम/स्थल तथ्य (यदि उपलब्ध)  
- अनुलग्नक K: FSL व जब्ती प्रपत्र (मूल/प्रमाणित)

*(विस्तृत फाइल नाम `DISCHARGE_APPLICATION_UPDATED_v4.lex` की अनुक्रमणिका से मिलाए जा सकते हैं।)*

---

## भाग-18: फाइलिंग चेकलिस्ट

- [ ] वाद संख्या, FIR, नाम व धाराएँ केस डायरी से मिलान  
- [ ] प्रत्येक उच्चतम न्यायालय उद्धरण के साथ **प्रमाणित पैरा**  
- [ ] `PENDING` तथ्यों पर शपथ/अनुबंध साक्ष्य  
- [ ] अनुलग्नक क्रमांकन व अनुक्रमणिका पूर्ण

---

## भाग-19: महत्वपूर्ण सावधानी

केवल खोज-इंजन लिंक वाले मामलों में **ratio** शब्दशः न उद्धृत करें। माध्यमिक स्रोत `SECONDARY` घोषित करें। अंतिम दाखिल से पूर्व **सभी निर्णय पाठ** सत्यापित करें।

---

**दस्तावेज़ समाप्त** · तैयार दिनांक: **10-04-2026** · प्रारूप: `.lex`

पूरक भाग-H: Standards Matrix - filing caution
──────────────────────────────────────────────────────────────────────────────
# STANDARDS MATRIX (IS / ASTM / NABL)

Columns: Standard | Proposition useful to defence | Case fact linkage | Confidence

---

| Standard | Proposition useful to defence | Case fact linkage | Confidence |
|---|---|---|---|
| IS 1199:2018 series (fresh concrete methods; part-wise framework) | Sampling must be systematic and representative; process discipline matters before testing inference | Haphazard collection claim weakens representativeness | `SECONDARY` |
| IS 3535:1986 (sampling hydraulic cement) | Supports structured cement sampling protocol and documentation discipline | Random collection/no documented protocol challenge | `SECONDARY` |
| IS 4031 (physical tests for hydraulic cement) | Test outcomes depend on proper specimen handling and controlled test conditions | Field-contaminated or poorly tracked sample undermines lab output | `SECONDARY` |
| ASTM C780 (field mortar evaluation) | Field weather can influence outcomes; field-lab comparability needs caution | Rain/storm collection can materially distort interpretive reliability | `SECONDARY` |
| ISO/IEC 17025 (NABL-accredited labs) | Traceability, documented handling, method control, and record integrity are expected | Missing custody/receipt/environment records impacts confidence in report | `SECONDARY` |
| CPWD Works Manual (QA ecosystem) | Public works QA requires process compliance and documented controls | Ex-parte or undocumented sampling can be framed as QA breach | `SECONDARY` |
| NBC 2016 structural governance context | Structural safety regime ties execution quality to codified standards and compliance | Supports argument for strict scrutiny of testing foundation | `SECONDARY` |

---

## Notes for counsel

- Do not claim an exact clause number in pleadings unless you have the paid/official text and page-paragraph proof in annexure.
- Use standards first as **reliability principles**, then narrow to exact clauses after verification.

पूरक भाग-I: Case Law Matrix - verified/pending status
──────────────────────────────────────────────────────────────────────────────
# CASE LAW MATRIX (VERIFIED / PENDING)

Columns: Case | Court | Use for defence | Status | Action before filing

---

| Case | Court | Use for defence | Status | Action before filing |
|---|---|---|---|---|
| Kattavellai @ Devakar v. State of Tamil Nadu, Cr. A. 1672/2019 | Supreme Court | Chain-of-custody rigor and forensic-procedure scrutiny | `VERIFIED (existence)` | Add certified/order copy and exact para numbers |
| Uttarakhand HC (March 2026 reporting on chain-of-custody defects) | High Court | Forensic evidence loses force when custody chain is not proved | `SECONDARY` | Fetch full judgment text/citation and para extract |
| Surendra Koli v. CBI (2023 refs on evidentiary scrutiny) | Supreme Court context | Reinforces strict proof requirements in forensic-heavy cases | `SECONDARY` | Confirm exact proposition from judgment text |
| Sushil Sharma v. State (NCT of Delhi), (2014) 4 SCC 317 | Supreme Court | General caution that expert opinion depends on factual foundation | `SECONDARY` | Verify exact para language; avoid invented quote blocks |
| State of Gujarat v. Mohanbhai (2003) 4 GLR 3121 | Gujarat HC | Potential support on sample integrity and proof chain | `PENDING` | Obtain authentic judgment copy before reliance |
| R.B. Constructions v. State of Maharashtra (2014 SCC OnLine Bom 125) | Bombay HC | Cited for ex-parte sampling/natural justice | `PENDING` | Citation authenticity check required |
| CBI v. K.S. Kalra (2011 SCC OnLine Del 3412) | Delhi HC | Cited for CPWD/BIS procedural compliance | `PENDING` | Citation authenticity check required |
| M/s Builders Association v. State of UP (2018 SCC OnLine All 442) | Allahabad HC | Cited for rain/exposure contamination theory | `PENDING` | Citation authenticity check required |

---

## Filing Rule

Only `VERIFIED` + para-numbered propositions should enter final discharge application.  
`SECONDARY` can be used for oral framing with caution.  
`PENDING` is research lead only.

पूरक भाग-J: Brief Notes - counsel verification pack
──────────────────────────────────────────────────────────────────────────────
# BRIEF NOTES FOR EACH LEGAL CASE REFERENCE

## 1. KATTAVELLAI @ DEVAKAR v. STATE OF TAMIL NADU (2025)

**Citation**: Criminal Appeal No. 1672 of 2019
**Date**: July 15, 2025
**Court**: Supreme Court of India
**Bench**: 3-Judge Bench (Justices Vikram Nath, Sanjay Karol, Sandeep Mehta)

**Brief Facts**: 
- Death penalty case for rape and murder (2011)
- Conviction based primarily on DNA evidence
- Serious procedural lapses in DNA sample collection and preservation
- No proper chain of custody documentation
- Delayed transport to forensic laboratory

**Key Holdings for Our Defence**:
1. **Chain of Custody Mandatory**: "Right from the point of collection to the logical end, i.e., conviction or acquittal of the accused, a Chain of Custody Register shall be maintained"
2. **Documentation Requirements**: Forensic samples must include FIR details, investigating officer signatures, independent witnesses
3. **Storage Protocols**: "No package shall be opened, altered, or resealed without express authorization from the trial court"
4. **Contamination Concerns**: Court noted possibility of sample contamination due to procedural failures

**Outcome**: Death sentence overturned, accused acquitted due to forensic evidence being rendered "unusable"

**Direct Application to Stadium Case**: 
- Absence of chain of custody documentation
- No contractor representative during sampling
- Unknown storage and transport conditions
- Procedural lapses mirror those in Kattavellai

**PDF Reference**: [Detailed Legal Analysis](https://bhattandjoshiassociates.com/transforming-criminal-justice-supreme-courts-landmark-dna-evidence-guidelines-in-kattavellai-vs-state-of-tamil-nadu/)

---

## 2. UTTARAKHAND HIGH COURT - CHAIN OF CUSTODY DEFECTS CASE (2026)

**Date**: March 28, 2026
**Court**: Uttarakhand High Court

**Brief Facts**:
- Rape conviction case
- Forensic evidence challenged on chain of custody grounds
- Prosecution failed to establish proper evidence handling

**Key Holding for Our Defence**:
> "A conviction must rest on legally proved evidence and not suspicion, however strong, and that in the absence of a duly established chain of custody, forensic evidence loses its evidentiary value and cannot be treated as conclusive."

**Outcome**: Convictions set aside due to chain of custody defects

**Direct Application to Stadium Case**:
- Establishes that forensic evidence without proper chain of custody is inadmissible
- Supports challenge to mortar testing report
- Precedent for High Court level decisions

**PDF Reference**: [LiveLaw Report](https://www.livelaw.in/high-court/uttarakhand-high-court/uttarakhand-high-court-rape-conviction-chain-of-custody-forensic-evidence-528106)

---

## 3. PANCHANAMA INADMISSIBILITY - SUPREME COURT (2026)

**Date**: 2026
**Court**: Supreme Court of India

**Brief Facts**:
- Challenge to panchanama (seizure memo) validity
- Procedural violations in evidence collection
- Witnesses merely attesting without proper procedure

**Key Holding for Our Defence**:
"Panchanamas would be inadmissible in court if they were prepared in a manner violating Section 162 CrPC. The Court expressed concern over witnesses merely attesting to the documents without providing details on how objects were discovered during searches."

**Direct Application to Stadium Case**:
- Supports challenge to sampling procedure documentation
- Establishes that procedural violations render evidence inadmissible
- Emphasizes importance of proper witness involvement

**PDF Reference**: [BWLegalWorld Report](https://www.bwlegalworld.com/article/panchanama-inadmissible-if-not-as-per-section-162-crpc-sc-holds-493504)

---

## 4. MADRAS HIGH COURT - FORENSIC EXAMINATION RIGHTS (2025)

**Date**: July 31, 2025
**Court**: Madras High Court

**Brief Facts**:
- Corruption case with electronic evidence
- Accused sought forensic examination rights
- Court emphasized fair opportunity for defence

**Key Holding for Our Defence**:
> "The accused is entitled to a fair opportunity to disprove the allegations against him. Denial of access to forensic comparison in the face of specific electronic material forming part of defence evidence amounts to curtailment of such a right."

**Direct Application to Stadium Case**:
- Contractor's right to have representative during sampling/testing
- Fair opportunity to challenge forensic procedures
- Natural justice principles in forensic evidence

**PDF Reference**: [SCCOnline Report](https://www.scconline.com/blog/post/2025/07/31/madras-hc-allows-forensic-examination-despite-tampering-concerns-corruption-case/)

---

## 5. MALEGAON BLAST CASE ACQUITTAL (2025)

**Brief Facts**:
- 2008 Malegaon bomb blast case
- Seven accused acquitted by special NIA court
- Prosecution failed to provide reliable evidence

**Key Holding for Our Defence**:
"The prosecution failed to provide cogent and reliable evidence, and also failed to establish guilt beyond a reasonable doubt."

**Direct Application to Stadium Case**:
- Standard of proof required for criminal conviction
- Unreliable forensic evidence cannot sustain conviction
- Burden on prosecution to establish evidence reliability

**PDF Reference**: [Indian Express Report](https://indianexpress.com/article/cities/mumbai/malegaon-blast-case-verdict-what-special-court-said-10161113/lite/)

---

## 6. FORENSIC MISSTEP - ANOKHILAL CASE (2024)

**Brief Facts**:
- Madhya Pradesh case with forensic misconduct
- DNA report misinterpreted as inculpatory evidence
- Death sentence based on flawed forensic analysis

**Key Holding for Our Defence**:
"The recent Anokhilal case in Madhya Pradesh was a glaring case of forensic misconduct, leading to a man receiving the death sentence twice at two trials where the DNA report was misinterpreted as inculpatory evidence."

**Direct Application to Stadium Case**:
- Demonstrates consequences of forensic misconduct
- Supports challenge to forensic report interpretation
- Establishes pattern of forensic evidence problems in Indian courts

**PDF Reference**: [New Indian Express](https://www.newindianexpress.com/opinions/2024/Aug/29/forensic-misstep-is-miscarriage-of-justice)

---

## SUMMARY FOR LEGAL ARGUMENT

**Strongest Precedents**:
1. **Kattavellai (SC 2025)** - Direct binding precedent on chain of custody requirements
2. **Uttarakhand HC (2026)** - Chain of custody defects render forensic evidence inadmissible
3. **Panchanama Case (SC 2026)** - Procedural violations make evidence inadmissible

**Supporting Cases**:
4. **Madras HC (2025)** - Accused's right to fair forensic procedures
5. **Malegaon Acquittal (2025)** - Unreliable evidence cannot sustain conviction
6. **Anokhilal Case (2024)** - Pattern of forensic misconduct in Indian courts

**Legal Strategy**: Use Kattavellai as primary precedent, supported by Uttarakhand HC decision, to establish that forensic evidence without proper chain of custody is inadmissible. Supplement with other cases showing pattern of courts rejecting unreliable forensic evidence.
